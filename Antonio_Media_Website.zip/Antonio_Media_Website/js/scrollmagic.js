$(document).ready(function () {

    var controller = new ScrollMagic.Controller();

    var ourScene = new ScrollMagic.Scene({
            triggerElement: '#nav-trigger',
            triggerHook: 'onLeave'

        })
        .setClassToggle('#navbar', 'lock-nav')
        .addTo(controller);

    var ourScene2 = new ScrollMagic.Scene({
            triggerElement: '#side-nav-1-trigger',
            triggerHook: '0.15'

        })

        .setClassToggle('#side-nav-1', 'lock-side-nav-1')
        .addTo(controller);

    var ourScene3 = new ScrollMagic.Scene({
            triggerElement: '#side-nav-2-trigger',
            triggerHook: '0.15'

        })

        .setClassToggle('#side-nav-1', 'unlock-side-nav-1')
        .addTo(controller);

    var ourScene4 = new ScrollMagic.Scene({
            triggerElement: '#side-nav-2-trigger',
            triggerHook: '0.15'

        })


        .setClassToggle('#side-nav-2', 'lock-side-nav-2')
        .addTo(controller);

    var ourScene5 = new ScrollMagic.Scene({
            triggerElement: '#side-nav-3-trigger',
            triggerHook: '0.15'

        })

        .setClassToggle('#side-nav-2', 'unlock-side-nav-2')
        .addTo(controller);

    var ourScene6 = new ScrollMagic.Scene({
            triggerElement: '#side-nav-3-trigger',
            triggerHook: '0.15'

        })

        .setClassToggle('#side-nav-3', 'lock-side-nav-3')
        .addTo(controller);

    var ourScene7 = new ScrollMagic.Scene({
            triggerElement: '#side-nav-4-trigger',
            triggerHook: '0.15'

        })

        .setClassToggle('#side-nav-3', 'unlock-side-nav-3')
        .addTo(controller);
    
    var ourScene8 = new ScrollMagic.Scene({
            triggerElement: '#side-nav-4-trigger',
            triggerHook: '0.15'

        })

        .setClassToggle('#side-nav-4', 'lock-side-nav-4')
        .addTo(controller);

    var ourScene9 = new ScrollMagic.Scene({
            triggerElement: '#side-nav-5-trigger',
            triggerHook: '0.15'

        })
        .setClassToggle('#side-nav-4', 'unlock-side-nav-4')
        .addTo(controller);
    
    var ourScene10 = new ScrollMagic.Scene({
            triggerElement: '#side-nav-5-trigger',
            triggerHook: '0.15'

        })

        .setClassToggle('#side-nav-5', 'lock-side-nav-5')
        .addTo(controller);

    var ourScene11 = new ScrollMagic.Scene({
            triggerElement: '#side-nav-6-trigger',
            triggerHook: '0.15'

        })

        .setClassToggle('#side-nav-5', 'unlock-side-nav-5')
        .addTo(controller);
});