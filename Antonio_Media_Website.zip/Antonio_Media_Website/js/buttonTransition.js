$('.leesverder').on('click', function(e){
    var ripple = $(this).find('.btnSpan');

    $(this).find('.btnSpan').removeClass('ripple');

    var dim = Math.max($(this).outerWidth(), $(this).outerHeight());
    $('.leesverder').find('.btnSpan').css({
        height: dim,
        width: dim
    });

    var offset = $(this).offset();
    var x = e.pageX - offset.left - ripple.width() / 2;
    var y = e.pageY - offset.top - ripple.height() / 2;


    ripple.css({top: y+'px', left: x+'px'
    }).addClass('ripple');

});