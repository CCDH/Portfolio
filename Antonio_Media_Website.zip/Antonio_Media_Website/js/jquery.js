

$(function () {
   var slider = new SliderUnlock("#slider", {}, function () {
      $("#slider").css({display:"none"});
      // $(".contact-p").css({display:"none"});
      // $(".contact-h1").css({display:"none"});
      $(".form-container").removeClass('hidden', 1000);
   });

   slider.init();
});

$(function(){
       // When the toggle areas in your navbar are clicked, toggle them
       $("#search-button, #search-icon").click(function(e){
           e.preventDefault();
           $("#search-button, #search-form").toggle();
       });
    })  ;

    var theScroll;
    function scroll() {
        theScroll = new iScroll('wrapper');
    }
    document.addEventListener('DOMContentLoaded', scroll, false);

    if ($(window).width() < 992) {
      //  alert('Less than 960');
       $('scroll-div').removeClass('dragscroll');
       $('scroll-div').addClass('scroll-content');
    }
    else {
      //  alert('More than 960');
       $('scroll-div').addClass('dragscroll');
       $('scroll-div').removeClass('scroll-content');
    }

    $(function () {
        $('#homeCarousel').carousel({
            interval: false
        });
    });
