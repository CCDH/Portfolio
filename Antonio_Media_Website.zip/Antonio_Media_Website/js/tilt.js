var aFx = 70,
    trF = 4;
$('.container-margin-design').on('mousemove touchmove',function(e){
    var cH = $('.container-margin-design').innerHeight(),
        cW = $('.container-margin-design').innerWidth(),
        eX = (e.originalEvent.type === 'touchmove') ? e.originalEvent.touches[0].pageX  : e.offsetX,
        eY = (e.originalEvent.type === 'touchmove') ? e.originalEvent.touches[0].pageY  : e.offsetY;

    $.each($('.design-img-1'), function(i,el){
        //console.log(((eY - cH / 2) / aFx) - (i*2));
        TweenMax.set( $(el),{
            transformOrigin: ((eX / (cW*trF) / 100 * 10000) + (trF * 10))+'% '+((eY / (cH*trF) / 100 * 10000) + (trF * 10))+'%',
            transformPerspective: 1000 + (i * 500)});
        TweenMax.to( $(el), 0.5, {
            rotationX: ((eY - cH / 2) / aFx) - i * 2,
            rotationY: ((eX - cW / 2) / aFx * -1) - i * 2,
            y:(eY - (cH / 2)) / (70 - i * 20),
            x:(eX - (cW / 2)) / (70 - i * 20)
        });
    });

}).on('mouseout touchend',function(e){
    $.each($('.design-img-1'),function(i,el){
        TweenMax.to( $(el), 1, {
            delay:.2,
            y:0,
            x:0,
            rotationX: 0,
            rotationY: 0,
            transformPerspective:'1500'
        });
    });
});

$('.container-margin-dev').on('mousemove touchmove',function(e){
    var cH = $('.container-margin-dev').innerHeight(),
        cW = $('.container-margin-dev').innerWidth(),
        eX = (e.originalEvent.type === 'touchmove') ? e.originalEvent.touches[0].pageX  : e.offsetX,
        eY = (e.originalEvent.type === 'touchmove') ? e.originalEvent.touches[0].pageY  : e.offsetY;

    $.each($('.dev-img-1'), function(i,el){
        //console.log(((eY - cH / 2) / aFx) - (i*2));
        TweenMax.set( $(el),{
            transformOrigin: ((eX / (cW*trF) / 100 * 10000) + (trF * 10))+'% '+((eY / (cH*trF) / 100 * 10000) + (trF * 10))+'%',
            transformPerspective: 1000 + (i * 500)});
        TweenMax.to( $(el), 0.5, {
            rotationX: ((eY - cH / 2) / aFx) - i * 2,
            rotationY: ((eX - cW / 2) / aFx * -1) - i * 2,
            y:(eY - (cH / 2)) / (70 - i * 20),
            x:(eX - (cW / 2)) / (70 - i * 20)
        });
    });

}).on('mouseout touchend',function(e){
    $.each($('.dev-img-1'),function(i,el){
        TweenMax.to( $(el), 1, {
            delay:.2,
            y:0,
            x:0,
            rotationX: 0,
            rotationY: 0,
            transformPerspective:'1500'
        });
    });
});

$('.container-margin-workshops').on('mousemove touchmove',function(e){
    var cH = $('.container-margin-workshops').innerHeight(),
        cW = $('.container-margin-workshops').innerWidth(),
        eX = (e.originalEvent.type === 'touchmove') ? e.originalEvent.touches[0].pageX  : e.offsetX,
        eY = (e.originalEvent.type === 'touchmove') ? e.originalEvent.touches[0].pageY  : e.offsetY;

    $.each($('.workshops-img-1'), function(i,el){
        //console.log(((eY - cH / 2) / aFx) - (i*2));
        TweenMax.set( $(el),{
            transformOrigin: ((eX / (cW*trF) / 100 * 10000) + (trF * 10))+'% '+((eY / (cH*trF) / 100 * 10000) + (trF * 10))+'%',
            transformPerspective: 1000 + (i * 500)});
        TweenMax.to( $(el), 0.5, {
            rotationX: ((eY - cH / 2) / aFx) - i * 2,
            rotationY: ((eX - cW / 2) / aFx * -1) - i * 2,
            y:(eY - (cH / 2)) / (70 - i * 20),
            x:(eX - (cW / 2)) / (70 - i * 20)
        });
    });

}).on('mouseout touchend',function(e){
    $.each($('.workshops-img-1'),function(i,el){
        TweenMax.to( $(el), 1, {
            delay:.2,
            y:0,
            x:0,
            rotationX: 0,
            rotationY: 0,
            transformPerspective:'1500'
        });
    });
});

$('.container-margin').on('mousemove touchmove',function(e){
    var cH = $('.container-margin').innerHeight(),
        cW = $('.container-margin').innerWidth(),
        eX = (e.originalEvent.type === 'touchmove') ? e.originalEvent.touches[0].pageX  : e.offsetX,
        eY = (e.originalEvent.type === 'touchmove') ? e.originalEvent.touches[0].pageY  : e.offsetY;

    $.each($('.what-am-img'), function(i,el){
        //console.log(((eY - cH / 2) / aFx) - (i*2));
        TweenMax.set( $(el),{
            transformOrigin: ((eX / (cW*trF) / 100 * 10000) + (trF * 10))+'% '+((eY / (cH*trF) / 100 * 10000) + (trF * 10))+'%',
            transformPerspective: 1000 + (i * 500)});
        TweenMax.to( $(el), 0.5, {
            rotationX: ((eY - cH / 2) / aFx) - i * 2,
            rotationY: ((eX - cW / 2) / aFx * -1) - i * 2,
            y:(eY - (cH / 2)) / (70 - i * 20),
            x:(eX - (cW / 2)) / (70 - i * 20)
        });
    });

}).on('mouseout touchend',function(e){
    $.each($('.what-am-img'),function(i,el){
        TweenMax.to( $(el), 1, {
            delay:.2,
            y:0,
            x:0,
            rotationX: 0,
            rotationY: 0,
            transformPerspective:'1500'
        });
    });
});

$('.container-margin-vac').on('mousemove touchmove',function(e){
    var cH = $('.container-margin-vac').innerHeight(),
        cW = $('.container-margin-vac').innerWidth(),
        eX = (e.originalEvent.type === 'touchmove') ? e.originalEvent.touches[0].pageX  : e.offsetX,
        eY = (e.originalEvent.type === 'touchmove') ? e.originalEvent.touches[0].pageY  : e.offsetY;

    $.each($('.who-am-img'), function(i,el){
        //console.log(((eY - cH / 2) / aFx) - (i*2));
        TweenMax.set( $(el),{
            transformOrigin: ((eX / (cW*trF) / 100 * 10000) + (trF * 10))+'% '+((eY / (cH*trF) / 100 * 10000) + (trF * 10))+'%',
            transformPerspective: 1000 + (i * 500)});
        TweenMax.to( $(el), 0.5, {
            rotationX: ((eY - cH / 2) / aFx) - i * 2,
            rotationY: ((eX - cW / 2) / aFx * -1) - i * 2,
            y:(eY - (cH / 2)) / (70 - i * 20),
            x:(eX - (cW / 2)) / (70 - i * 20)
        });
    });

}).on('mouseout touchend',function(e){
    $.each($('.who-am-img'),function(i,el){
        TweenMax.to( $(el), 1, {
            delay:.2,
            y:0,
            x:0,
            rotationX: 0,
            rotationY: 0,
            transformPerspective:'1500'
        });
    });
});