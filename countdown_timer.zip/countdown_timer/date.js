	function countDown() {
		var verjaardag = new Date(2018, 05, 19);
		var heden = new Date();
		var milliseconden = verjaardag - heden;

		var dagen = Math.floor(milliseconden / (1000 * 60 * 60 * 24));
		var uren = Math.floor((milliseconden % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
		var minuten = Math.floor((milliseconden % (1000 * 60 * 60)) / (1000 * 60));
		var seconden = Math.floor((milliseconden % (1000 * 60)) / 1000);




		console.log(Math.ceil(seconden));
		document.getElementById("demo").innerHTML = dagen + " dagen " + uren + " uren " + minuten + " minuten " + seconden + " seconden ";
	}
	//setInterval(countDown, 1000);
	function pageLoad() {
    var startButton = document.getElementById("start");

    startButton.onclick = setInterval(alertMe,200);
}

function alertMe() {
  alert("hi");
}

/*
 var init = function(selector, settings) {
        mergeObjects(defaultSettings, settings || {});
        selector = selector || defaultSettings.selector;
        element = document.querySelector(selector);
        speedY = 0;
        timer = setInterval(update, defaultSettings.updateSpeed);
    };

    //Return the functions that should be accessible from the outside. The rest is only accessible from within the object
    return {
        init: init
    }; */

/*window.onload = function() {

	countDown();

	function countDown() {
		var verjaardag = new Date(2018, 7, 16);
		var heden = new Date();
		var milliseconden = verjaardag - heden;

		var seconden = milliseconden / 1000;
		var minuten = seconden / 60;
		var uren = minuten / 60;
		var dagen = uren / 24;

		console.log(Math.ceil(seconden));
		document.getElementById("demo").innerHTML = Math.floor(seconden);
	}
	setInterval(countDown, 1000);
}
*/