var mijnHeader = document.querySelector('h1');
mijnHeader.textContent = 'Welkom op mijn testpagina,';

var paragraph = document.querySelector('.uitleg');
paragraph.textContent =
  'Dit is een testpagina. Je kunt hier verschillende dingen doen die uitgevoerd worden door Javascript. Zo kun je bijvoorbeeld door op de bovenstaande foto te klikken deze veranderen naar een andere afbeelding. Er is minimale HTML omdat je vrijwel alles kunt doen via de JavaScript ';

var myImage = document.querySelector('img');

myImage.onclick = function() {
  var mySrc = myImage.getAttribute('src');
  if (mySrc === '') {
    myImage.setAttribute('src', 'images/testfoto2.jpeg');
  } else {
    myImage.setAttribute('src', 'images/testfoto2.jpeg');
  }
}

var myButton = document.querySelector('button');
var mijnHeader = document.querySelector('h1');

function setUserName() {
  var Naam = prompt('Voer hier uw naam in.');
  localStorage.setItem('name', Naam);
  mijnHeader.textContent = 'Welkom op mijn portfolio, ' +
    Naam;
}

if (!localStorage.getItem('name')) {
  setUserName();
} else {
  var storedName = localStorage.getItem('name');
  myHeading.textContent = 'Welkom op mijn testpagina, ' + storedName;
}

myButton.onclick = function() {
  setUserName();
}
