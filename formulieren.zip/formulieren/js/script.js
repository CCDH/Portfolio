document.getElementById("formGevonden02").style.display = "none";
document.getElementById("formGevonden03").style.display = "none";

function wijzig_cat1() {
  document.getElementById("formGevonden01").style.display = "block";
  document.getElementById("formGevonden02").style.display = "none";
  document.getElementById("formGevonden03").style.display = "none";
  document.getElementById("balls1").style.display = "flex";
  document.getElementById("balls2").style.display = "none";
  document.getElementById("balls3").style.display = "none";
  document.getElementById('controle_modal').style.display = "none";
  $(document).unbind('scroll');
    $('body').css({
      'overflow': 'visible'
    });
}

function wijzig_cat2() {
  document.getElementById("formGevonden01").style.display = "none";
  document.getElementById("formGevonden02").style.display = "block";
  document.getElementById("formGevonden03").style.display = "none";
  document.getElementById("balls1").style.display = "none";
  document.getElementById("balls2").style.display = "flex";
  document.getElementById("balls3").style.display = "none";
  document.getElementById('controle_modal').style.display = "none";
  $(document).unbind('scroll');
    $('body').css({
      'overflow': 'visible'
    });
}

function wijzig_cat3() {
  document.getElementById("formGevonden01").style.display = "none";
  document.getElementById("formGevonden02").style.display = "none";
  document.getElementById("formGevonden03").style.display = "block";
  document.getElementById("balls1").style.display = "none";
  document.getElementById("balls2").style.display = "none";
  document.getElementById("balls3").style.display = "flex";
  document.getElementById('controle_modal').style.display = "none";
  $(document).unbind('scroll');
    $('body').css({
      'overflow': 'visible'
    });
}

function verderBtnOne() {
  document.getElementById("formGevonden01").style.display = "none";
  document.getElementById("formGevonden02").style.display = "block";
  document.getElementById("balls1").style.display = "none";
  document.getElementById("balls2").style.display = "flex";
}

function terugBtnTwo() {
  document.getElementById("formGevonden01").style.display = "block";
  document.getElementById("formGevonden02").style.display = "none";
  document.getElementById("balls1").style.display = "flex";
  document.getElementById("balls2").style.display = "none";
}

function verderBtnTwo() {
  document.getElementById("formGevonden02").style.display = "none";
  document.getElementById("formGevonden03").style.display = "block";
  document.getElementById("balls2").style.display = "none";
		document.getElementById("balls3").style.display = "flex";
}

function terugBtnThree() {
  document.getElementById("formGevonden03").style.display = "none";
  document.getElementById("formGevonden02").style.display = "block";
  document.getElementById("balls3").style.display = "none";
  document.getElementById("balls2").style.display = "flex";
}

function controlBtnThree() {
  document.getElementById('controle_modal').style.display = "block";
  $('body').css({
    'overflow': 'hidden'
  });
  $(document).bind('scroll', function() {
    window.scrollTo(0, 0);
  });
}

function toggleCheckbox() {
  document.getElementById("eigenaartrue").style.display = "none";
  document.getElementById("eigenaarfalse").style.display = "block";
  var checkBox = document.getElementById("checkboxcheck");
  if (checkBox.checked) {
    document.getElementById("eigenaartrue").style.display = "block";
    document.getElementById("eigenaarfalse").style.display = "none";
  } else {
    document.getElementById("eigenaartrue").style.display = "none";
    document.getElementById("eigenaarfalse").style.display = "block";
  }
}

document.getElementById("checkboxcheck").checked = true;

function waarheidCheck(){
    var checkbox = document.getElementById("waarheid_check");
    var verzendbutton = document.getElementById("verzendbutton");

    if(checkbox.checked){
        verzendbutton.disabled = false;
    }

    else{
        verzendbutton.disabled = true;
    }
}

$(document).ready(function() {
  $(function() {
    $("#datepicker").datepicker({
      autoclose: true,
      format: 'dd-mm-yyyy',
      todayHighlight: true
    }).datepicker('update', new Date());



  });



  $(".dropdown-menu li a").click(function() {
    $(this).parents(".dropdown").find('.btn').html($(this).text() +
      ' <span class="caret"></span>');
    $(this).parents(".dropdown").find('.btn').val($(this).data('value'));
  });

  // Get the modal
  var modal = document.getElementById('myModal');
  var controleModal = document.getElementById('controle_modal');

  // Get the button that opens the modal
  var btn = document.getElementById("myBtn");
  var controleBtn = document.getElementById("controleren03");

  // Get the <span> element that closes the modal
  var span = document.getElementById("close_tips");
  var controleSpan = document.getElementById("close_controleer");
  var controleAnnuleer = document.getElementById("annuleer_controle");

  // When the user clicks the button, open the modal
  btn.onclick = function() {
    modal.style.display = "block";
    $('body').css({
      'overflow': 'hidden'
    });
    $(document).bind('scroll', function() {
      window.scrollTo(0, 0);
    });
  };

  // When the user clicks on <span> (x), close the modal
  span.onclick = function() {
    modal.style.display = "none";
    $(document).unbind('scroll');
    $('body').css({
      'overflow': 'visible'
    });
  };

  controleSpan.onclick = function() {
    controleModal.style.display = "none";
    $(document).unbind('scroll');
    $('body').css({
      'overflow': 'visible'
    });
  };

   controleAnnuleer.onclick = function() {
    controleModal.style.display = "none";
    $(document).unbind('scroll');
    $('body').css({
      'overflow': 'visible'
    });
  };

  // When the user clicks anywhere outside of the modal, close it
  window.onclick = function(event) {
    if (event.target == modal) {
      modal.style.display = "none";
      $(document).unbind('scroll');
      $('body').css({
        'overflow': 'visible'
      });
    } else if (event.target == controleModal) {
      controleModal.style.display = "none";
      $(document).unbind('scroll');
      $('body').css({
        'overflow': 'visible'
      });
    }
  };


  //Photo upload
  $(document).on('click', '.upload-field', function() {
    var file = $(this).parent().parent().parent().find('.input-file');
    file.trigger('click');
  });
  $(document).on('change', '.input-file', function() {
    $(this).parent().find('.form-control').val($(this).val().replace(
      /C:\\fakepath\\/i, ''));
  });

});
