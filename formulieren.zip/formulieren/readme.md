#Documentatie

https://getbootstrap.com/docs/3.3/getting-started/

##Modal

https://www.w3schools.com/howto/howto_css_modals.asp